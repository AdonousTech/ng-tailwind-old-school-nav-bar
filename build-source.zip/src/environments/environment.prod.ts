export const environment = {
  production: true,
  authData: {
    IdentityPoolId: 'us-west-2:3fabdca3-8ef2-4fec-b216-55be20aa863b',
    UserPoolId: 'us-west-2_lVInSQ6W9',
    Region: 'us-west-2',
    UserPoolWebClientId: '38oujk4vevr5jjh1rnv836791a'
  }
};
